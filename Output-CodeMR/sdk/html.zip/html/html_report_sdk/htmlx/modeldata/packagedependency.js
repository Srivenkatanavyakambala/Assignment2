var matrix = [[0,0,1,2,0,0],[0,0,0,0,0,0],[0,0,0,1,0,0],[0,0,0,0,0,0],[0,12,0,0,0,12],[1,4,0,0,0,0]]
var packages = [{
"name": " ikidou.reflect", "color": " #3182bd"
}
,{
"name": " cn.wildfirechat.sdk.model", "color": " #6baed6"
}
,{
"name": " ikidou.reflect.typeimpl", "color": " #9ecae1"
}
,{
"name": " ikidou.reflect.exception", "color": " #c6dbef"
}
,{
"name": " cn.wildfirechat.sdk", "color": " #e6550d"
}
,{
"name": " cn.wildfirechat.sdk.utilities", "color": " #fd8d3c"
}
];
