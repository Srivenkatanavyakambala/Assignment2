var EQ_workingSetList = [
{name: 'apollo-audit-spring-boot-starter', path:'apollo-audit-spring-boot-starter'}
];
