var EQ_workingSetList = [
{name: 'jsonschema2pojo-gradle-plugin', path:'jsonschema2pojo-gradle-plugin'}
];
