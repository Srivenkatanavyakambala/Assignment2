var matrix = [[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,0,0,0,0,0],[0,0,6,6,0,0,1],[1,1,0,1,1,0,1],[0,0,1,1,0,0,0]]
var packages = [{
"name": " io.restassured.internal.path.json", "color": " #3182bd"
}
,{
"name": " io.restassured.path.json.exception", "color": " #6baed6"
}
,{
"name": " io.restassured.path.json.mapping", "color": " #9ecae1"
}
,{
"name": " io.restassured.path.json.mapper.factory", "color": " #c6dbef"
}
,{
"name": " io.restassured.internal.path.json.mapping", "color": " #e6550d"
}
,{
"name": " io.restassured.path.json", "color": " #fd8d3c"
}
,{
"name": " io.restassured.path.json.config", "color": " #fdae6b"
}
];
