var matrix = [[0,0,0,0,2,1],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,1,0,0,0,0],[0,0,0,0,0,0]]
var packages = [{
"name": " org.apache.seatunnel.common.utils", "color": " #3182bd"
}
,{
"name": " org.apache.seatunnel.common.constants", "color": " #6baed6"
}
,{
"name": " org.apache.seatunnel.common.utils.function", "color": " #9ecae1"
}
,{
"name": " org.apache.seatunnel.common.config", "color": " #c6dbef"
}
,{
"name": " org.apache.seatunnel.common.exception", "color": " #e6550d"
}
,{
"name": " org.apache.seatunnel.common", "color": " #fd8d3c"
}
];
