var matrix = [[0,0,0,0,0,0,0,0,0,3],[1,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[1,1,0,0,0,0,1,0,1,1],[0,0,0,2,0,0,0,0,0,0],[4,0,0,0,0,0,0,1,1,3],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,1,0,0]]
var packages = [{
"name": " com.ctrip.framework.apollo.configservice.util", "color": " #3182bd"
}
,{
"name": " com.ctrip.framework.apollo.configservice.filter", "color": " #6baed6"
}
,{
"name": " com.ctrip.framework.apollo.metaservice", "color": " #9ecae1"
}
,{
"name": " com.ctrip.framework.apollo.metaservice.service", "color": " #c6dbef"
}
,{
"name": " com.ctrip.framework.apollo.configservice", "color": " #e6550d"
}
,{
"name": " com.ctrip.framework.apollo.metaservice.controller", "color": " #fd8d3c"
}
,{
"name": " com.ctrip.framework.apollo.configservice.controller", "color": " #fdae6b"
}
,{
"name": " com.ctrip.framework.apollo.configservice.wrapper", "color": " #fdd0a2"
}
,{
"name": " com.ctrip.framework.apollo.configservice.service.config", "color": " #31a354"
}
,{
"name": " com.ctrip.framework.apollo.configservice.service", "color": " #74c476"
}
];
