var EQ_workingSetList = [
{name: 'mall-demo', path:'mall-demo'}
];
