var matrix = [[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,0,0,0,0,0],[0,1,0,1,0,0,0,0],[0,0,0,0,0,0,0,0],[0,1,0,1,0,0,0,0],[0,0,0,0,0,0,0,0]]
var packages = [{
"name": " com.macro.mall.demo.validator", "color": " #3182bd"
}
,{
"name": " com.macro.mall.demo.dto", "color": " #6baed6"
}
,{
"name": " com.macro.mall.demo", "color": " #9ecae1"
}
,{
"name": " com.macro.mall.demo.service", "color": " #c6dbef"
}
,{
"name": " com.macro.mall.demo.controller", "color": " #e6550d"
}
,{
"name": " com.macro.mall.demo.config", "color": " #fd8d3c"
}
,{
"name": " com.macro.mall.demo.service.impl", "color": " #fdae6b"
}
,{
"name": " com.macro.mall.demo.bo", "color": " #fdd0a2"
}
];
