var EQ_workingSetList = [
{name: 'jsonschema2pojo-cli', path:'jsonschema2pojo-cli'}
];
