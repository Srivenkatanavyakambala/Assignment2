var matrix = [[0,0,0],[0,0,6],[1,1,0]]
var packages = [{
"name": " com.iluwatar.abstractdocument.domain.enums", "color": " #3182bd"
}
,{
"name": " com.iluwatar.abstractdocument.domain", "color": " #6baed6"
}
,{
"name": " com.iluwatar.abstractdocument", "color": " #9ecae1"
}
];
