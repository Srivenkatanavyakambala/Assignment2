var matrix = [[0,0,0],[0,0,0],[0,0,0]]
var packages = [{
"name": " com.ctrip.framework.apollo.audit.event", "color": " #3182bd"
}
,{
"name": " com.ctrip.framework.apollo.audit.api", "color": " #6baed6"
}
,{
"name": " com.ctrip.framework.apollo.audit.dto", "color": " #9ecae1"
}
];
