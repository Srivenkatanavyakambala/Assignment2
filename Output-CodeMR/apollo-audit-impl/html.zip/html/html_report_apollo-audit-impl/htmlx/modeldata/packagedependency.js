var matrix = [[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[2,0,0,0,2,0,0,0,1,0,0,0,0],[1,0,1,0,2,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,2,1,0,0,0,0,0,0,0,0,2,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,2,0,0,1,0,0,1,0,0,1,0],[0,0,0,0,0,0,0,0,0,0,0,1,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[1,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,0,0,0,0],[0,0,0,0,0,0,0,0,0,1,0,0,0]]
var packages = [{
"name": " com.ctrip.framework.apollo.audit.constants", "color": " #3182bd"
}
,{
"name": " com.ctrip.framework.apollo.audit.repository", "color": " #6baed6"
}
,{
"name": " com.ctrip.framework.apollo.audit.context", "color": " #9ecae1"
}
,{
"name": " com.ctrip.framework.apollo.audit.spi.defaultimpl", "color": " #c6dbef"
}
,{
"name": " com.ctrip.framework.apollo.audit.spi", "color": " #e6550d"
}
,{
"name": " com.ctrip.framework.apollo.audit.service", "color": " #fd8d3c"
}
,{
"name": " com.ctrip.framework.apollo.audit.listener", "color": " #fdae6b"
}
,{
"name": " com.ctrip.framework.apollo.audit.component", "color": " #fdd0a2"
}
,{
"name": " com.ctrip.framework.apollo.audit.util", "color": " #31a354"
}
,{
"name": " com.ctrip.framework.apollo.audit", "color": " #74c476"
}
,{
"name": " com.ctrip.framework.apollo.audit.aop", "color": " #a1d99b"
}
,{
"name": " com.ctrip.framework.apollo.audit.entity", "color": " #c7e9c0"
}
,{
"name": " com.ctrip.framework.apollo.audit.controller", "color": " #756bb1"
}
];
