var EQ_workingSetList = [
{name: 'apollo-adminservice', path:'apollo-adminservice'}
];
