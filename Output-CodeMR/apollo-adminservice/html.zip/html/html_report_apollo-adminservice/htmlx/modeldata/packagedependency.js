var matrix = [[0,0,1,0],[0,0,0,0],[0,0,0,0],[0,0,0,0]]
var packages = [{
"name": " com.ctrip.framework.apollo.adminservice", "color": " #3182bd"
}
,{
"name": " com.ctrip.framework.apollo.adminservice.controller", "color": " #6baed6"
}
,{
"name": " com.ctrip.framework.apollo.adminservice.filter", "color": " #9ecae1"
}
,{
"name": " com.ctrip.framework.apollo.adminservice.aop", "color": " #c6dbef"
}
];
