var EQ_workingSetList = [
{name: 'abstract-factory', path:'abstract-factory'}
];
